# Bounded EditMark evidence handoff

All changes are private. No canonical file, repository, frozen G evidence,
paper PDF or old experimental campaign was changed. This is a completed new
finite controlled case, not independent validation of a program population.

## What changed scientifically

Six authored list-processing tasks (three development, three held out) supply
true unembedded controls beside actual native bootstrap-encoder outputs. Five
task semantics are new; guarded sum repeats the old arithmetic case. Payloads
0/5/10/15 are configurations, not four independent programs. Both origins and
both sides receive exactly the same registered schedule; the detector never
receives the origin label or `negative_control=True`.

The preregistered separate consumer uses the native positive-support gate
fraction, not confidence or a probability. Development-only selection under a
zero-false-positive constraint chooses threshold9/8, the explicit reject-all
boundary. This is a failed useful operating-point selection, not successful
probability calibration. All frozen inputs, the selection-before-holdout digest,
raw pairs, native outputs and source-generation registries are retained.

There are96 attempted pairs,12 excluded encoder-no-op pairs,84 admitted pairs,
and29,952 exact finite-contract calls with zero failures. The no-op pairs are
retained. Each held-out edit has12 controls from3 base texts and9 changed-encoder
contexts from7 distinct original texts. None of these counts is independent
program sampling.

Held-out registered native results:

| Edit | Native hits / all controls | Native hits / eligible embedding positives | Score AUC on9+9 matched contexts |
| --- | --- | --- | --- |
| Comment footer |2/12 |5/9 |68/81 |
| Reference reimplementation |2/12 |2/9 |1/2 |

For the same matched cohort, control hits are2/9 in both edits; do not mix that
denominator with the all-controls2/12. All9 reimplementation contexts have
identical edited text from the two origins. The selected9/8 score rule has
FPR=TPR=0 on holdout. Native schedule reconstruction without supplied generation
notes has zero native positive hits:21/21 eligible comment rows abstain and
21/21 reference-reimplementation rows reject. Its score AUC is1/3 for comment
and1/2 after reimplementation; do not invert its direction after seeing holdout.

The native support gate requires generation-time discriminative rewrite notes.
Empty-schedule reconstruction does not create them, so its positive gate fails.
The exact body locations and false-hit/payload-recovery rows are in
`raw-recount.json`. Fixing that mechanism would require another explicitly
authorized design/validation task, not silently adding oracle schedule data.

## Implementation / focused checks

`candidate/collect.py` performs source-authenticated native collection and
pure-AST/finite-contract admission. `candidate/score_consumer.py` is a separate
raw-file scoring entrypoint: it imports neither encoder nor detector nor the
collector. `candidate/run_bounded.py` enforces the single cumulative Linux
budget and phased development-selection-holdout ordering. All8 focused tests
passed; these are software checks, not extra experimental subjects.

The completed batch used68.459s active wall,60.720s child CPU and54,005,760bytes
peak child RSS. The read-only recount brings active execution totals to68.588s
wall/60.783s CPU. These are resource receipts, not scientific latency estimates.
Archive verification has its own remaining-budget receipt; no native execution
is repeated. Old source-linked measurements stay byte-identical.

## Standard lossless publication transport

`publication/editmark-owned-controls-evidence.zip` is an ordinary deterministic
ZIP, not a custom codec. It contains the full collected observations, native
vendor outputs, source registries, frozen protocol/selection, all logs, candidate
sources and readouts. `MANIFEST.json` records every original member's size and
SHA256. Full raw files remain private and unchanged.

Use the standard-library verifier in a new private extraction directory:

```text
python -B verify_evidence_archive.py ARCHIVE.zip NEW_PRIVATE_DIRECTORY
```

It validates member names and the exact manifest, uses `zipfile.extractall`,
checks every original byte, reruns only the extracted scoring consumer and
requires byte-identical `run_001/result.json`. An independently written
rank-sum/tie-block AUC recount challenges the consumer's pairwise arithmetic.
It does not authenticate detector execution or repeat source execution.

## Parent-only integration

1. Review the raw/candidate evidence and the standard archive verification
   receipt. Apply `integration.patch` only if accepting the new case.
2. Preserve the complete ZIP as an ordinary binary evidence payload (connector
   `create_blob` binary/base64 is sufficient), together with its archive SHA and
   MANIFEST. If source-level consumers are desired, unpack this directory's
   relative layout into a separate opt-in artifact example; do not import it
   from the default model-free suite.
3. Preserve `RUN_BUDGET_LOCK.json` and all retained measurements. The existing
   run is finished; do not delete the lock or relaunch native collection as a
   packaging check. Verification/scoring reads retained rows only.
4. Keep existing positive-only certificate denials unchanged. The new negative
   and score consumer is not implemented in those old certificate schemas.
5. Rebuild the manuscript only through the parent workflow, and regenerate
   current file inventories last. No new author, licence, source provenance,
   model comparison or deployment claim is authorized by this handoff.

Suggested patch command, from a parent-reviewed content-only project copy:

```text
git apply --check /path/to/integration.patch
git apply /path/to/integration.patch
```

These are integration instructions, not commands executed by this worker.
