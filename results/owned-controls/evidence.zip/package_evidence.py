"""Build one ordinary deterministic ZIP and verify under remaining user caps."""
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import resource
import signal
import stat
import subprocess
import sys
import time
import zipfile
import zlib

ROOT=Path(__file__).resolve().parent


def read(p): return json.loads(p.read_text('utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,m):
    if not v: raise ValueError(m)
def write(p,v):
    with p.open('x',encoding='utf-8') as f: json.dump(v,f,sort_keys=True,indent=2); f.write('\n')


def main():
    prior=read(ROOT/'postprocess-budget-receipt.json')
    cpu_prior=prior['cumulative_cpu_seconds']; wall_prior=prior['cumulative_active_execution_wall_seconds']
    need(cpu_prior<180 and wall_prior<300,'No remaining original budget')
    resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
    cpu_left=math.floor(180-cpu_prior); wall_left=math.floor(300-wall_prior)
    resource.setrlimit(resource.RLIMIT_CPU,(cpu_left,cpu_left)); signal.alarm(wall_left)
    started=time.monotonic(); cpu_start=time.process_time()
    publication=ROOT/'publication'; need(not publication.exists(),'Keep previous publication bytes; no overwrite')
    publication.mkdir()
    inputs=[ROOT/p for p in ('PROTOCOL.json','RUN_BUDGET_LOCK.json','SAFETY-AND-SCOPE.md','INTEGRATION.md',
        'integration.patch','raw-recount.json','postprocess-budget-receipt.json','review_raw_results.py',
        'verify_evidence_archive.py','package_evidence.py')]
    inputs += [p for p in (ROOT/'candidate').glob('*.py') if p.is_file()]
    inputs += [p for p in (ROOT/'run_001').rglob('*') if p.is_file()]
    need(not any('__pycache__' in p.parts for p in inputs),'Unexpected bytecode')
    files={p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(inputs)}
    manifest={'schema':'EDITMARK_FULL_RAW_EVIDENCE_ZIP_V1','files':files,
        'scope':'Lossless collected paired observations/native outputs/registries/protocol/selection and consumers; constructed task families, not independent program sampling',
        'entrypoint':'verify_evidence_archive.py ARCHIVE NEW_PRIVATE_DIRECTORY',
        'original_raw_results':'run_001/result.json','native_code_distribution':'No native vendor code is copied; original source identities and output traces are retained'}
    manifest_bytes=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
    (publication/'MANIFEST.json').write_bytes(manifest_bytes)
    archive=publication/'editmark-owned-controls-evidence.zip'
    members={'MANIFEST.json':manifest_bytes,**{rel:(ROOT/rel).read_bytes() for rel in files}}
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in sorted(members):
            info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0)); info.create_system=3
            info.external_attr=(stat.S_IFREG|0o644)<<16; info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,members[name],compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    del members
    command=[sys.executable,'-B',str(ROOT/'verify_evidence_archive.py'),str(archive),str(publication/'reconstructed')]
    remaining_cpu=max(1,math.floor(180-cpu_prior-(time.process_time()-cpu_start)))
    def limit(): resource.setrlimit(resource.RLIMIT_CPU,(remaining_cpu,remaining_cpu))
    with (publication/'verification.stdout.log').open('x') as stdout, (publication/'verification.stderr.log').open('x') as stderr:
        checked=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=max(1,wall_left-(time.monotonic()-started)),preexec_fn=limit)
    need(checked.returncode==0,'Archive verification failed; preserve archive/logs')
    verification=read(publication/'reconstructed/verification-receipt.json')
    need(all(sha(ROOT/rel)==x['sha256'] for rel,x in files.items()),'Original raw/source bytes changed')
    child=resource.getrusage(resource.RUSAGE_CHILDREN)
    cpu=time.process_time()-cpu_start+child.ru_utime+child.ru_stime
    duration=time.monotonic()-started
    need(cpu_prior+cpu<180 and wall_prior+duration<300,'Original cumulative user caps exceeded')
    receipt={'status':'FULL_RAW_ARCHIVE_VERIFIED','archive':str(archive),'archive_bytes':archive.stat().st_size,
        'archive_sha256':sha(archive),'manifest_sha256':sha(publication/'MANIFEST.json'),
        'original_files':len(files),'uncompressed_original_bytes':sum(x['bytes'] for x in files.values()),
        'verification':verification,'native_execution_repeated':False,'old_raw_files_preserved':True,
        'cumulative_active_execution_wall_seconds':wall_prior+duration,'cumulative_cpu_seconds':cpu_prior+cpu,
        'peak_packager_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        'peak_verification_child_rss_bytes':child.ru_maxrss*1024,'ram_limit_bytes':1073741824,
        'within_original_user_caps':True,'scientific_timing':False,'standard_transport':'ZIP_DEFLATED; fixed1980timestamp; sorted members; regular0644files',
        'zlib_runtime_version':zlib.ZLIB_RUNTIME_VERSION,'canonical_G_or_repository_written':False}
    write(publication/'receipt.json',receipt)
    print(json.dumps({k:receipt[k] for k in ('status','archive_bytes','archive_sha256','original_files','uncompressed_original_bytes','cumulative_active_execution_wall_seconds','cumulative_cpu_seconds')}))


if __name__=='__main__': main()
