"""Read-only raw-evidence recount, with remaining (not reset) batch resources."""
from collections import Counter
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import resource
import signal
import sys
import time

HOME=Path(__file__).resolve().parent
RUN=HOME/'run_001'


def read(p): return json.loads(p.read_text('utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,m):
    if not v: raise ValueError(m)
def write(p,v):
    with p.open('x',encoding='utf-8') as f: json.dump(v,f,ensure_ascii=False,sort_keys=True,indent=2); f.write('\n')
def f(v): return {'numerator':v.numerator,'denominator':v.denominator}


def main():
    before=read(RUN/'budget-receipt.json')
    need(before['status']=='COMPLETED','Incomplete native batch')
    used=before['child_cpu_seconds_total']; wall=before['wall_seconds_resource_accounting_only']
    resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
    left=math.floor(180-used); need(left>0 and wall<300,'No remaining budget')
    resource.setrlimit(resource.RLIMIT_CPU,(left,left)); signal.alarm(math.floor(300-wall))
    start=time.monotonic(); cpu=time.process_time()
    freeze=read(RUN/'freeze.json')
    need(all(sha(HOME/rel)==value for rel,value in freeze['candidate_sha256'].items()),'Frozen candidate changed')
    rows=[]
    for split in ('development','holdout'):
        rows += [json.loads(line) for line in (RUN/split/'pairs.jsonl').read_text('utf-8').splitlines()]
    calls=[c for r in rows for side in ('original','edited') for c in r[side]['validation']['calls']]
    result=read(RUN/'result.json')
    need(len(calls)==result['counts']['validation_calls'],'Raw call count mismatch')
    held=[r for r in rows if r['split']=='holdout']
    excluded=[{'task':r['task'],'payload':r['payload'],'edit':r['edit'],'reason':r['first_exclusion']}
              for r in rows if r['first_exclusion']]
    context={}
    for r in held:
        if r['first_exclusion'] is None: context.setdefault((r['context_id'],r['edit']),{})[r['label']]=r
    summaries={}
    hits=[]
    for edit in ('review-footer','reference-reimplementation'):
        matches=[pair for (key,e),pair in context.items() if e==edit and set(pair)=={0,1}]
        controls=[r for r in held if r['edit']==edit and r['label']==0 and r['first_exclusion'] is None]
        for r in controls:
            o=r['edited']['detections']['registered']['output']
            if o['is_watermarked']:
                hits.append({'task':r['task'],'payload':r['payload'],'edit':edit,
                    'source_sha256':r['edited']['source_sha256'],'native_status':o['decision_status'],
                    'native_recovered_payload':o['wm_id_hat'],'score':o['positive_support_score']})
        summaries[edit]={
            'all_eligible_control_contexts':len(controls),
            'matched_contexts':len(matches),
            'matched_control_native_hits':sum(g[0]['edited']['detections']['registered']['output']['is_watermarked'] for g in matches),
            'matched_control_native_fpr':f(Fraction(sum(g[0]['edited']['detections']['registered']['output']['is_watermarked'] for g in matches),len(matches))),
            'matched_positive_native_hits':sum(g[1]['edited']['detections']['registered']['output']['is_watermarked'] for g in matches),
            'within_context_same_edited_text':sum(g[0]['edited']['source_sha256']==g[1]['edited']['source_sha256'] for g in matches),
            'control_fpr_denominator_not_auc_denominator':'All-control FPR uses12contexts; pooled AUC compares9positive and9matched-negative contexts. Both are dependent configurations from3task families.'}
    positives=[r for r in rows if r['label']==1 and r['edit']=='review-footer']
    payloads={}
    for split in ('development','holdout'):
        subset=[r for r in positives if r['split']==split]
        eligible=[r for r in subset if r['first_exclusion'] is None]
        payloads[split]={
            'attempted_embedding_contexts':len(subset),
            'encoder_noops':[{'task':r['task'],'payload':r['payload']} for r in subset if not r['encoder_changed']],
            'eligible_original_native_hits':sum(r['original']['detections']['registered']['output']['is_watermarked'] for r in eligible),
            'eligible_original_hits_wrong_recovered_payload':[{'task':r['task'],'payload':r['payload'],'recovered':r['original']['detections']['registered']['output']['wm_id_hat']}
                for r in eligible if r['original']['detections']['registered']['output']['is_watermarked'] and r['original']['detections']['registered']['output']['wm_id_hat']!=r['payload']],
            'eligible_original_source_texts':len({r['original']['source_sha256'] for r in eligible})}
    value={'status':'RAW_RECOUNT_COMPLETE','native_execution_repeated':False,
        'function_calls':len(calls),'functional_failures':sum(not c['passed'] for c in calls),
        'attempted_pairs':len(rows),'admitted_pairs':sum(r['first_exclusion'] is None for r in rows),
        'exclusions':excluded,'exclusion_counts':dict(Counter(x['reason'] for x in excluded)),
        'heldout_registered_control_false_hits':hits,'heldout_same_population_details':summaries,
        'embedding_coverage':payloads,
        'frozen_inputs_unchanged':True,'result_sha256':sha(RUN/'result.json'),
        'body_located_obstruction':{
            'native_source_commit':freeze['upstream_commit'],
            'schedule_constructor':'vendor/semcodebook/variant_pool.py:91-194: reconstructed entries have adaptive_data_slot/fingerprint notes, not generation-time discriminative flags',
            'required_flags':'vendor/semcodebook/negative_controls.py:45-99: rewrite support requires discriminative_rewrite_backed_carrier, rewrite_aligned or generation-planned notes',
            'acceptance':'vendor/semcodebook/negative_controls.py:202-209 and detector.py:318: without rewrite-backed families the positive gate fails; only accepted support plus a decoded value produces watermarked status',
            'label_leak_guard':'detector.py:309-317: negative_control=True would force rejection; this input is False for both origins in every collected call',
            'boundary':'No new detector repair is proposed: adding a deployment-capable schedule reconstruction and revalidating discrimination would change the mechanism and is outside this bounded evidence extension.'}}
    write(HOME/'raw-recount.json',value)
    duration=time.monotonic()-start; cost=time.process_time()-cpu
    write(HOME/'postprocess-budget-receipt.json',{'scope':'Read-only raw recount, no new native observations',
        'previous_budget_receipt_sha256':sha(RUN/'budget-receipt.json'),
        'additional_cpu_seconds':cost,'additional_wall_seconds':duration,
        'cumulative_cpu_seconds':used+cost,'cumulative_active_execution_wall_seconds':wall+duration,
        'peak_recount_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        'ram_limit_bytes':1073741824,'native_execution_repeated':False,'campaign_reset':False,
        'within_original_user_caps':used+cost<180 and wall+duration<300})
    print(json.dumps({'calls':len(calls),'failures':value['functional_failures'],'admitted_pairs':value['admitted_pairs'],'exclusion_counts':value['exclusion_counts']}))


if __name__=='__main__': main()
