# EditMark local candidate: scope and integration boundary

This directory is a private candidate, not a change to the delivered artifact.
`PROTOCOL.json` precedes native execution. The single `run_001` batch freezes
that protocol, all six candidate Python files, and the retained historical
input identities. Its lock is not permission to start another campaign.

## Source and execution review

The current manuscript's ten section sources, artifact README/reviewer guide,
runtime-safety guidance, existing owned-carrier fixture/runner, and existing
SemCodebook runner were inspected. The retained processing costs are historical;
this candidate does not extend or compare their timing series. The relevant
configuration budgets concern archived model/attack workflows; none is invoked.
No separate cumulative execution cap was found for the owner-authored opt-in
source case in those inputs. The new user cap is enforced for this one batch,
not used to reopen any old campaign.

The included provenance identifies the native source as author-owned at commit
`f2434164a4bd022099d98e5fa6236cd04e01968a`, and explicitly reports no upstream
LICENSE/COPYING. This is not relabeled as licensed third-party software. The
candidate imports that existing owner-provided source in place after checking
every recorded Git blob. It does not download or redistribute it.

Reviewed call paths are `rule_based_generate` and its target-aligned schedule,
local Python carrier rewrites, and native `detect`/support gates. In particular,
the support gate reads generation-time schedule notes; supplying the native
`negative_control=True` would force rejection. The candidate never supplies
that flag for either origin. Trained-generation, checkpoint, external program
validation and attack entrypoints are not called. An audit hook rejects model
imports, network/process execution and file writes outside this private root.

Our task sources contain only finite-list arithmetic. The execution admission
guard rejects imports, attributes, external calls and unknown function names.
This is a finite owned-input guard, not a general security sandbox. Linux
address-space, cumulative CPU and wall limits bound the complete batch.

## Interpretation

Origin labels record a real local construction event: an unembedded authored
base versus the actual native encoder output. They do not certify that every
attempt carried a correct payload. Encoder no-ops, validation failures,
missing detector results, misses and wrong recovered values are retained.
Four payload schedules per task are dependent configurations; source counts
and task counts must remain separate.

The registered rule supplies the same task/payload schedule to both classes.
Its gate-fraction score is declared in advance and is not native confidence or
a probability. A separate consumer selects an empirical development operating
point before holdout collection. This supports only conditional descriptive
ROC/FPR questions if the admitted classes have the declared coverage. It is
not posterior calibration or blind provenance inference.

The reference-reimplementation edit deliberately maps both histories to the
same prewritten source within each task/payload context. That is a useful
origin-collision control, not a representative natural-edit distribution.
Native content-only reconstruction is a separately reported rule, not an
unannounced replacement for the registered schedule.

The current EditMark positive-only certificate interfaces remain unchanged.
New negative/score evidence must not retroactively mark an old FPR/AUC request
admissible. Parent integration should add a separate opt-in example/consumer,
preserve the historical case and its denials, and amend only the scoped new
case-study/limitation text after reviewing the actual receipt.
