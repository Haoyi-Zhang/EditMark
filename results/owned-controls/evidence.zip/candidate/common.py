"""Local serialization and source-admission utilities; no model dependencies."""
import ast
import hashlib
import json
from pathlib import Path

HOME = Path(__file__).resolve().parents[1]


def need(value, message):
    if not value: raise ValueError(message)


def digest(value):
    if isinstance(value, str): value = value.encode('utf-8')
    return hashlib.sha256(value).hexdigest()


def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
def read(path): return json.loads(Path(path).read_text('utf-8-sig'))


def write_new(path, value):
    path = Path(path).resolve()
    need(path.is_relative_to(HOME), 'Only private worker-c outputs allowed')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        f.write('\n')


SAFE_BUILTINS = {'range': range, 'len': len, 'int': int, 'sum': sum, 'max': max,
                 'min': min, 'any': any, 'all': all, 'zip': zip, 'enumerate': enumerate,
                 'abs': abs, 'list': list, 'bool': bool}


def admit(source):
    """Deny imports, attributes, nested code construction and external calls.

    This is a whitelist for our finite pure arithmetic sources, NOT a sandbox
    offered to arbitrary callers. The whole process also has CPU/RAM limits.
    """
    need(type(source) is str and len(source.encode()) <= 16384, 'Source size/type')
    tree = ast.parse(source)
    need(tree.body and all(isinstance(n, ast.FunctionDef) for n in tree.body), 'Only function declarations')
    names = {n.name for n in tree.body}
    need(names <= {'solve', 'helper_transform'} and 'solve' in names, 'Unknown function')
    forbidden = (ast.Import, ast.ImportFrom, ast.Attribute, ast.ClassDef, ast.Lambda,
                 ast.Global, ast.Nonlocal, ast.AsyncFunctionDef, ast.Await, ast.With,
                 ast.Try, ast.Raise, ast.Delete, ast.Yield, ast.YieldFrom)
    for n in ast.walk(tree):
        need(not isinstance(n, forbidden), 'Unsupported source AST '+type(n).__name__)
        if isinstance(n, ast.FunctionDef): need(not n.decorator_list, 'No decorators')
        if isinstance(n, ast.Name): need('__' not in n.id, 'No dunder names')
        if isinstance(n, ast.Call):
            need(isinstance(n.func, ast.Name) and n.func.id in (set(SAFE_BUILTINS)|names), 'Unknown call')
    return tree
