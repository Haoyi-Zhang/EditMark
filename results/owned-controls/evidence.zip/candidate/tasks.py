"""New owner-authored benign tasks; no benchmark inputs or external code.

Related finite fixtures, not a sampled independent-program population.
"""
from itertools import product

PAYLOADS = (0, 5, 10, 15)
DOMAIN = [list(t) for n in range(4) for t in product((-2, -1, 0, 1, 2), repeat=n)]
FOOTER = "# Reviewed finite-task implementation.\n"
TASKS = {
    "guarded_sum": {
        "split": "development", "family": "guarded-fold",
        "base": "def solve(items):\n    total = 0\n    for item in items:\n        if item < 0:\n            return 0\n        total += item\n    return total\n",
        "replacement": "def solve(items):\n    return 0 if any(value < 0 for value in items) else sum(items)\n",
    },
    "count_even": {
        "split": "development", "family": "predicate-count",
        "base": "def solve(items):\n    total = 0\n    for item in items:\n        if item % 2 == 0:\n            total += 1\n    return total\n",
        "replacement": "def solve(items):\n    return sum(value % 2 == 0 for value in items)\n",
    },
    "product": {
        "split": "development", "family": "multiplicative-fold",
        "base": "def solve(items):\n    result = 1\n    for value in items:\n        result *= value\n    return result\n",
        "replacement": "def solve(items):\n    result = 1\n    index = 0\n    while index < len(items):\n        result = result * items[index]\n        index += 1\n    return result\n",
    },
    "sum_squares": {
        "split": "holdout", "family": "nonlinear-fold",
        "base": "def solve(items):\n    total = 0\n    for item in items:\n        total += item * item\n    return total\n",
        "replacement": "def solve(items):\n    return sum(value ** 2 for value in items)\n",
    },
    "maximum_prefix": {
        "split": "holdout", "family": "prefix-state",
        "base": "def solve(items):\n    total = 0\n    highest = 0\n    for item in items:\n        total += item\n        if total > highest:\n            highest = total\n    return highest\n",
        "replacement": "def solve(items):\n    return max([0] + [sum(items[:end]) for end in range(1, len(items) + 1)])\n",
    },
    "adjacent_rises": {
        "split": "holdout", "family": "adjacent-relation",
        "base": "def solve(items):\n    count = 0\n    for index in range(1, len(items)):\n        if items[index] > items[index - 1]:\n            count += 1\n    return count\n",
        "replacement": "def solve(items):\n    return sum(right > left for left, right in zip(items, items[1:]))\n",
    },
}


def expected(task, values):
    """Separately written finite-task oracle, not an encoder/detector result."""
    if task == "guarded_sum":
        return 0 if min(values, default=0) < 0 else sum(values)
    if task == "count_even":
        return len([x for x in values if x % 2 == 0])
    if task == "product":
        out = 1
        for x in values: out *= x
        return out
    if task == "sum_squares": return sum(x*x for x in values)
    if task == "maximum_prefix":
        sums = [0]
        for x in values: sums.append(sums[-1] + x)
        return max(sums)
    if task == "adjacent_rises":
        return len([i for i in range(len(values)-1) if values[i+1] > values[i]])
    raise ValueError("Unknown task")
