"""Focused non-native tests: no additional encoder/detector/task executions."""
from fractions import Fraction
import json
import unittest

from common import HOME, admit, digest, need, read
from score_consumer import auc, choose, first_exclusion, load
from tasks import TASKS


class CandidateTests(unittest.TestCase):
    def test_tie_aware_auc_and_missing_label_denial(self):
        self.assertEqual(auc([Fraction(1),Fraction(1,2)],[Fraction(1,2),Fraction(0)])['value'],
                         {'numerator':7,'denominator':8})
        self.assertEqual(auc([Fraction(1,2)],[Fraction(1,2)])['value'],{'numerator':1,'denominator':2})
        with self.assertRaises(ValueError): auc([Fraction(1)],[])

    def test_development_only_zero_fp_selection_is_exact(self):
        rows=[{'edit':'review-footer','first_exclusion':None,'label':y,
               'edited':{'detections':{'registered':{'output':{'positive_support_score':v}}}}}
              for y,v in [(1,1),(1,0.875),(0,0.75),(0,0.75)]]
        self.assertEqual(choose(rows)['threshold'],{'numerator':7,'denominator':8})
        with self.assertRaises(ValueError): choose([r for r in rows if r['label']])

    def test_pure_ast_guard_denies_execution_capabilities(self):
        for source in ("import os\n", "def solve(items):\n    return open('x')\n",
                       "def solve(items):\n    return items.__class__\n"):
            with self.assertRaises(ValueError): admit(source)
        for task in TASKS.values():
            admit(task['base']); admit(task['replacement'])

    def test_predeclared_family_split_not_payload_split(self):
        dev={x['family'] for x in TASKS.values() if x['split']=='development'}
        hold={x['family'] for x in TASKS.values() if x['split']=='holdout'}
        self.assertEqual((len(dev),len(hold)),(3,3)); self.assertFalse(dev & hold)

    def test_actual_raw_coverage_and_no_label_conditioned_spec(self):
        for split in ('development','holdout'):
            rows,_=load(HOME/'run_001'/split,split)
            self.assertEqual(len(rows),48)
            self.assertEqual(sum(r['label']==0 for r in rows),24)
            self.assertEqual(sum(r['label']==1 for r in rows),24)
            self.assertEqual(len({r['task'] for r in rows}),3)

    def test_exclusion_is_rederived_not_positive_selection(self):
        rows,_=load(HOME/'run_001/development','development')
        for row in rows: self.assertEqual(row['first_exclusion'],first_exclusion(row))
        row=json.loads(json.dumps(rows[0])); row['label']=1; row['encoder_changed']=False
        row['edited']['validation']['passed']=False
        self.assertEqual(first_exclusion(row),'encoder_unchanged_for_positive')

    def test_threshold_frozen_before_holdout_and_both_controls_kept(self):
        run=HOME/'run_001'; s=read(run/'selection.json'); h=read(run/'holdout/collection-receipt.json')
        self.assertIs(s['holdout_seen'],False)
        self.assertEqual(h['selection_sha256_before_holdout'],digest((run/'selection.json').read_bytes()))
        result=read(run/'result.json')
        self.assertEqual(result['counts']['attempted_pairs'],96)
        self.assertLessEqual(result['counts']['validation_calls'],29952)
        for values in result['metrics'].values():
            for metric in values:
                self.assertEqual(metric['attempted_pairs'],metric['admitted_pairs']+sum(metric['first_exclusions'].values()))

    def test_same_text_origin_collision_cannot_change_deterministic_output(self):
        for split in ('development','holdout'):
            rows,_=load(HOME/'run_001'/split,split)
            by={}
            for row in rows:
                if row['edit']=='reference-reimplementation': by.setdefault(row['context_id'],{})[row['label']]=row
            for pair in by.values():
                self.assertEqual(pair[0]['edited']['source'],pair[1]['edited']['source'])
                self.assertEqual(pair[0]['edited']['detections'],pair[1]['edited']['detections'])


if __name__=='__main__': unittest.main(verbosity=2)
