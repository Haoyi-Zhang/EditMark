"""One cumulative, opt-in Linux batch; no automatic campaign reset/retry."""
import argparse
import ast
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

from common import HOME, digest, need, write_new


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--artifact',type=Path,required=True)
    a=p.parse_args(); artifact=a.artifact.resolve(); output=HOME/'run_001'
    need(sys.platform=='linux','Use Linux resource limits; no unenforced Windows fallback')
    need(not output.exists() and not (HOME/'RUN_BUDGET_LOCK.json').exists(),'One campaign only; no reset/requalification')
    candidate=Path(__file__).resolve().parent
    source_bindings={str(path.relative_to(HOME)):digest(path.read_bytes()) for path in sorted(candidate.glob('*.py'))}
    for path in candidate.glob('*.py'): ast.parse(path.read_text('utf-8'))
    baseline_files=['README.md','LICENSE','vendor/SemCodebook-provenance.json','scripts/measure_semcodebook_cpu.py',
                    'results/semcodebook_cpu/pairs.jsonl','results/semcodebook_cpu/measurement.json',
                    'results/owned_finite_carrier/measurement.json']
    baseline={rel:digest((artifact/rel).read_bytes()) for rel in baseline_files if (artifact/rel).is_file()}
    freeze={'protocol_sha256':digest((HOME/'PROTOCOL.json').read_bytes()),'candidate_sha256':source_bindings,
            'baseline_sha256':baseline,'upstream_commit':'f2434164a4bd022099d98e5fa6236cd04e01968a',
            'utc_before_native_execution':datetime.now(timezone.utc).isoformat()}
    write_new(HOME/'RUN_BUDGET_LOCK.json',{'wall_cap':300,'cpu_cap':180,'ram_cap':1073741824,
              'counter_reset_permitted':False,'run_directory':'run_001','initially_consumed_native_calls':0})
    output.mkdir(); write_new(output/'freeze.json',freeze)
    resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
    started=time.monotonic(); phases=[]; status='FAILED'
    py=[sys.executable,'-B']; freeze_path=output/'freeze.json'
    commands=[
        ('development',py+[str(candidate/'collect.py'),'--artifact',str(artifact),'--out',str(output/'development'),'--split','development','--freeze',str(freeze_path)]),
        ('select',py+[str(candidate/'score_consumer.py'),'select','--development',str(output/'development'),'--freeze',str(freeze_path),'--out',str(output/'selection.json')]),
        ('holdout',py+[str(candidate/'collect.py'),'--artifact',str(artifact),'--out',str(output/'holdout'),'--split','holdout','--freeze',str(freeze_path),'--selection',str(output/'selection.json')]),
        ('score',py+[str(candidate/'score_consumer.py'),'report','--development',str(output/'development'),'--holdout',str(output/'holdout'),'--freeze',str(freeze_path),'--selection',str(output/'selection.json'),'--out',str(output/'result.json')]),
        ('focused-tests',py+[str(candidate/'test_candidate.py')])]
    failure=None
    try:
        for name,command in commands:
            used=resource.getrusage(resource.RUSAGE_CHILDREN)
            cpu_left=180-used.ru_utime-used.ru_stime
            wall_left=300-(time.monotonic()-started)
            need(cpu_left>1 and wall_left>1,'Cumulative budget exhausted; do not rerun')
            def limit():
                seconds=max(1,math.floor(cpu_left))
                resource.setrlimit(resource.RLIMIT_CPU,(seconds,seconds))
            with (output/(name+'.stdout.log')).open('x') as stdout, (output/(name+'.stderr.log')).open('x') as stderr:
                child=subprocess.Popen(command,cwd=candidate,stdout=stdout,stderr=stderr,
                    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},preexec_fn=limit,start_new_session=True)
                try: code=child.wait(timeout=wall_left)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid,signal.SIGKILL); child.wait(); raise RuntimeError('Total wall cap exhausted')
            phases.append({'name':name,'command':command,'returncode':code})
            need(code==0,'Phase failed: '+name+'; preserve outputs, no automatic retry')
            need(sum(p.stat().st_size for p in output.rglob('*') if p.is_file())<=67108864,'Output cap')
        need(all(digest((artifact/rel).read_bytes())==sha for rel,sha in baseline.items()),'Historical bytes changed')
        need(all(digest((HOME/rel).read_bytes())==sha for rel,sha in source_bindings.items()),'Candidate changed during run')
        status='COMPLETED'
    except Exception as exc: failure=type(exc).__name__+': '+str(exc)
    used=resource.getrusage(resource.RUSAGE_CHILDREN)
    write_new(output/'budget-receipt.json',{'status':status,'failure':failure,'phases':phases,
        'wall_seconds_resource_accounting_only':time.monotonic()-started,
        'child_cpu_seconds_total':used.ru_utime+used.ru_stime,'peak_child_rss_bytes':used.ru_maxrss*1024,
        'ram_rlimit_as_bytes':1073741824,'historical_sha256_preserved':all(digest((artifact/rel).read_bytes())==sha for rel,sha in baseline.items()),
        'caps':{'wall_seconds':300,'cpu_seconds':180,'ram_bytes':1073741824,'output_bytes':67108864},
        'scientific_timing':False,'campaign_reset':False,'canonical_written':False})
    print(json.dumps({'status':status,'failure':failure,'output':str(output)}))
    return 0 if status=='COMPLETED' else 1


if __name__=='__main__': raise SystemExit(main())
