"""Opt-in native collector: only predeclared authored tasks, no metric selection."""
import argparse
from collections import Counter
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

from common import HOME, SAFE_BUILTINS, admit, canonical, digest, need, read, write_new
from tasks import DOMAIN, FOOTER, PAYLOADS, TASKS, expected


def authenticate(artifact):
    p = read(artifact/'vendor/SemCodebook-provenance.json')
    need(p['commit']=='f2434164a4bd022099d98e5fa6236cd04e01968a', 'Unexpected source version')
    checked=[]
    for item in p['files']:
        path=artifact/'vendor/semcodebook'/Path(item['path']).name
        data=path.read_bytes()
        blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        need(blob==item['git_blob'], 'Unpinned native source '+path.name)
        checked.append({'path':str(path),'git_blob':blob,'sha256':digest(data)})
    return checked


def runtime_guard(event, args):
    if event.startswith(('socket.', 'subprocess.', 'os.exec', 'os.spawn')) or event=='os.system':
        raise RuntimeError('Forbidden runtime operation '+event)
    if event=='import' and str(args[0]).split('.')[0] in {'torch','transformers','requests','httpx','openai'}:
        raise RuntimeError('Forbidden model/network import')
    if event=='open':
        name, mode, flags = args
        writing = (isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags & (1|2|64|512|1024))
        if writing and isinstance(name,(str,bytes)):
            need(Path(name).resolve().is_relative_to(HOME), 'Runtime write outside private root')


def validate(source, task, contract_id):
    try:
        tree=admit(source)
    except (ValueError,SyntaxError) as exc:
        return {'available':True,'passed':False,'contract_id':contract_id,'admitted_ast':False,
                'error':str(exc),'calls':[]}
    namespace={'__builtins__':SAFE_BUILTINS.copy()}
    try:
        exec(compile(tree,'<owned-finite-task>','exec'),namespace,namespace)
    except Exception as exc:
        return {'available':True,'passed':False,'contract_id':contract_id,'admitted_ast':True,
                'error':type(exc).__name__+': '+str(exc),'calls':[]}
    calls=[]
    for values in DOMAIN:
        wanted=expected(task,values)
        try:
            result=namespace['solve'](values.copy())
            passed=type(result) is int and result==wanted
            actual=result if type(result) in {int,bool,str,type(None)} else repr(result)
            error=None
        except Exception as exc:
            actual=None; passed=False; error=type(exc).__name__+': '+str(exc)
        calls.append({'input':values,'expected':wanted,'actual':actual,'passed':passed,'error':error})
    return {'available':True,'passed':all(x['passed'] for x in calls),'contract_id':contract_id,
            'admitted_ast':True,'calls':calls}


def exclusion(row):
    if row['label']==1 and not row['encoder_changed']: return 'encoder_unchanged_for_positive'
    if not all(row[s]['validation']['admitted_ast'] for s in ('original','edited')): return 'unsupported_source_ast'
    if row['original']['source_sha256']==row['edited']['source_sha256']: return 'unchanged_edit'
    if not row['original']['validation']['passed']: return 'original_contract_failed'
    if not row['edited']['validation']['passed']: return 'edited_contract_failed'
    if not all(row[s]['detections'][rule]['available'] for s in ('original','edited') for rule in ('registered','reconstructed')):
        return 'missing_native_output'
    return None


def run(artifact, output, split, freeze, selection=None):
    need(split in {'development','holdout'}, 'Unknown split')
    need(not output.exists() and output.resolve().is_relative_to(HOME), 'New private output required')
    frozen=read(freeze)
    for rel,sha in frozen['candidate_sha256'].items(): need(digest((HOME/rel).read_bytes())==sha,'Candidate changed since freeze '+rel)
    need(digest((HOME/'PROTOCOL.json').read_bytes())==frozen['protocol_sha256'], 'Protocol changed')
    if split=='holdout':
        need(selection is not None, 'Holdout requires preselected frozen threshold')
        selected=read(selection)
        need(selected['kind']=='DEVELOPMENT_OPERATING_POINT_SELECTION' and selected['holdout_seen'] is False, 'Invalid selection')
        need(selected['freeze_sha256']==digest(freeze.read_bytes()), 'Different selection protocol')
        selection_sha=digest(selection.read_bytes())
    else: selection_sha=None
    checked=authenticate(artifact)
    sys.addaudithook(runtime_guard)
    sys.path.insert(0,str(artifact/'vendor'))
    from semcodebook.inference import rule_based_generate
    from semcodebook.detector import SemCodebookDetector
    from semcodebook.protocol import GenerationRequest, WatermarkSpec
    detector=SemCodebookDetector()
    output.mkdir(parents=True,exist_ok=False)
    registry=[]; counts=Counter()
    raw=output/'pairs.jsonl'
    with raw.open('x',encoding='utf-8',newline='\n') as stream:
        for task,definition in TASKS.items():
            if definition['split']!=split: continue
            contract={'task':task,'domain':DOMAIN,'expected':[expected(task,v) for v in DOMAIN],
                      'output':'exact int; finite-domain contract only'}
            contract_id='finite-owned:'+digest(canonical(contract))
            for payload in PAYLOADS:
                request=GenerationRequest(prompt='Owned finite integer-list task '+task,language='python',
                    wm_id=payload,model_name='none',task_id=task,execution_mode='bootstrap_rule_based_generation',
                    candidate_budget=1)
                generated=rule_based_generate(request,definition['base'])
                counts['native_encoder_calls']+=1
                schedule=generated.carrier_schedule
                config={'task':task,'payload':payload,'schedule':[asdict(s) for s in schedule],
                        'carrier_key':'semcodebook-demo-key','native_threshold':0.5,
                        'implementation_stage':generated.implementation_stage,'negative_control':False,
                        'native_source_commit':frozen['upstream_commit']}
                registry.append({'task':task,'payload':payload,'configuration':config,
                                 'generation':asdict(generated),'request':asdict(request),
                                 'base_sha256':digest(definition['base'])})
                specs={'registered':WatermarkSpec(wm_id=payload,carrier_schedule=schedule,implementation_stage=generated.implementation_stage),
                       'reconstructed':WatermarkSpec(wm_id=payload,implementation_stage=generated.implementation_stage)}
                rule_ids={mode:mode+':'+digest(canonical(config if mode=='registered' else {
                    'mode':mode,'wm_id':payload,'key':'semcodebook-demo-key','threshold':0.5,
                    'source_commit':frozen['upstream_commit']})) for mode in specs}
                for label,before in ((1,generated.watermarked_code),(0,definition['base'])):
                    for edit in ('review-footer','reference-reimplementation'):
                        after=before+FOOTER if edit=='review-footer' else definition['replacement']
                        row={'schema':'OWNED_MATCHED_CONTROL_PAIR_V1','task':task,'family':definition['family'],
                             'split':split,'payload':payload,'context_id':task+':'+str(payload),'label':label,
                             'label_basis':'native_encoder_event' if label else 'unembedded_authored_base',
                             'encoder_changed':generated.watermarked_code!=definition['base'] if label else None,
                             'edit':edit,'supported':True,'detector_received_origin_label':False,
                             'registered_spec_sha256':digest(canonical(config))}
                        for side,source in (('original',before),('edited',after)):
                            validation=validate(source,task,contract_id)
                            counts['validation_calls']+=len(validation['calls'])
                            detections={}
                            for mode,spec in specs.items():
                                try:
                                    native=detector.detect(source,spec,language='python',negative_control=False)
                                    detections[mode]={'available':True,'rule_id':rule_ids[mode],'output':asdict(native)}
                                except Exception as exc:
                                    detections[mode]={'available':False,'rule_id':rule_ids[mode],
                                                      'error':type(exc).__name__+': '+str(exc)}
                                counts['external_native_detector_calls']+=1
                            row[side]={'source':source,'source_sha256':digest(source),
                                       'validation':validation,'detections':detections}
                        row['first_exclusion']=exclusion(row)
                        stream.write(json.dumps(row,sort_keys=True,allow_nan=False)+'\n'); stream.flush()
                        counts['attempted_pairs']+=1
    write_new(output/'registry.json',registry)
    write_new(output/'collection-receipt.json',{'split':split,'counts':dict(counts),'selection_sha256_before_holdout':selection_sha,
        'source_authentication':checked,'freeze_sha256':digest(freeze.read_bytes()),'pairs_sha256':digest(raw.read_bytes()),
        'detector_origin_label_flag':False,'negative_control_flag':False,'timing_is_scientific_measurement':False})
    if selection: need(digest(selection.read_bytes())==selection_sha,'Threshold changed during holdout')
    for rel,sha in frozen['candidate_sha256'].items(): need(digest((HOME/rel).read_bytes())==sha,'Candidate raced')
    print(json.dumps({'split':split,**dict(counts)}))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--artifact',type=Path,required=True); p.add_argument('--out',type=Path,required=True)
    p.add_argument('--split',choices=('development','holdout'),required=True)
    p.add_argument('--freeze',type=Path,required=True); p.add_argument('--selection',type=Path)
    a=p.parse_args(); run(a.artifact,a.out,a.split,a.freeze,a.selection)
