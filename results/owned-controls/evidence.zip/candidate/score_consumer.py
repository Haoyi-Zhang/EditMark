"""Separate raw-file consumer. Never imports native encoder/detector/collector.

Exact descriptive AUC and operating points, not posterior calibration.
"""
import argparse
from collections import Counter, defaultdict
from fractions import Fraction
import math
from pathlib import Path

from common import canonical, digest, need, read, write_new


def fraction(value): return {'numerator':value.numerator,'denominator':value.denominator}
def rate(values): return fraction(Fraction(sum(values),len(values))) if values else None


def score(output):
    value=output['positive_support_score']
    need(type(value) in {int,float} and math.isfinite(value) and 0<=value<=1, 'Invalid gate score')
    return Fraction(str(value))


def auc(positive,negative):
    need(positive and negative,'AUC requires both origin labels')
    wins=sum(p>n for p in positive for n in negative)
    ties=sum(p==n for p in positive for n in negative)
    denominator=len(positive)*len(negative)
    return {'value':fraction(Fraction(2*wins+ties,2*denominator)),
            'strict_wins':wins,'ties':ties,'comparisons':denominator}


def first_exclusion(row):
    if row['label']==1 and not row['encoder_changed']: return 'encoder_unchanged_for_positive'
    if not all(row[s]['validation']['admitted_ast'] for s in ('original','edited')): return 'unsupported_source_ast'
    if row['original']['source_sha256']==row['edited']['source_sha256']: return 'unchanged_edit'
    if not row['original']['validation']['passed']: return 'original_contract_failed'
    if not row['edited']['validation']['passed']: return 'edited_contract_failed'
    if not all(row[s]['detections'][m]['available'] for s in ('original','edited') for m in ('registered','reconstructed')):
        return 'missing_native_output'
    return None


def load(directory,expected_split):
    import json
    rows=[json.loads(line) for line in (directory/'pairs.jsonl').read_text('utf-8').splitlines()]
    receipt=read(directory/'collection-receipt.json')
    need(receipt['pairs_sha256']==digest((directory/'pairs.jsonl').read_bytes()),'Raw digest differs')
    registry={(x['task'],x['payload']):x for x in read(directory/'registry.json')}
    identities=set(); group=defaultdict(list)
    for row in rows:
        need(row['split']==expected_split and type(row['label']) is int and row['label'] in (0,1),'Wrong origin/split')
        identity=(row['context_id'],row['label'],row['edit'])
        need(identity not in identities,'Duplicate contextual observation'); identities.add(identity)
        need(row['detector_received_origin_label'] is False,'Detector received class label')
        reg=registry[(row['task'],row['payload'])]
        need(reg['configuration']['negative_control'] is False,'Negative-control veto forbidden')
        need(digest(canonical(reg['configuration']))==row['registered_spec_sha256'],'Wrong shared schedule')
        need(row['original']['source_sha256']==(digest(reg['generation']['watermarked_code']) if row['label'] else reg['base_sha256']), 'Origin/source substitution')
        need(row['label_basis']==('native_encoder_event' if row['label'] else 'unembedded_authored_base'),'False label basis')
        if row['label']:
            need(row['encoder_changed']==(digest(reg['generation']['watermarked_code'])!=reg['base_sha256']), 'False encoder change')
        need(row['original']['validation']['contract_id']==row['edited']['validation']['contract_id'], 'Contract drift')
        for side in ('original','edited'):
            program=row[side]; need(digest(program['source'])==program['source_sha256'],'Source mismatch')
            v=program['validation']
            if v['passed']:
                need(v['available'] is True and len(v['calls'])==156 and all(c['passed'] and type(c['actual']) is int and c['actual']==c['expected'] for c in v['calls']), 'False finite validation')
            for mode,d in program['detections'].items():
                need(d['rule_id']==row['original']['detections'][mode]['rule_id'],'Before/after rule drift')
                if d['available']:
                    o=d['output']; score(o)
                    need(type(o['is_watermarked']) is bool and o['is_watermarked']==(o['decision_status']=='watermarked'),'Native Boolean/status mismatch')
                    need(not any('negative_control_veto' in str(n) for n in o['notes']),'Label veto in native output')
        need(row['first_exclusion']==first_exclusion(row),'Exclusion partition differs')
        group[(row['context_id'],row['edit'])].append(row)
    for members in group.values():
        need({x['label'] for x in members}=={0,1} and len(members)==2,'Missing paired origin')
        need(len({x['registered_spec_sha256'] for x in members})==1,'Label-conditioned schedule')
    need(len(rows)==48 and len(registry)==12,'Predeclared split surface differs')
    return rows,receipt


def choose(rows):
    population=[r for r in rows if r['edit']=='review-footer' and r['first_exclusion'] is None]
    pos=[score(r['edited']['detections']['registered']['output']) for r in population if r['label']==1]
    neg=[score(r['edited']['detections']['registered']['output']) for r in population if r['label']==0]
    need(pos and neg,'No development operating point without both labels')
    options=[]
    for threshold in [Fraction(i,8) for i in range(10)]:
        fp=Fraction(sum(s>=threshold for s in neg),len(neg))
        tp=Fraction(sum(s>=threshold for s in pos),len(pos))
        if fp==0: options.append((tp,threshold))
    tp,threshold=max(options)
    return {'threshold':fraction(threshold),'development_tpr':fraction(tp),'development_fpr':fraction(Fraction(0)),
            'development_positive_contexts':len(pos),'development_negative_contexts':len(neg),
            'selection_scope':'registered review-footer; empirical zero-FP constraint, maximize TPR then highest threshold'}


def as_fraction(value): return Fraction(value['numerator'],value['denominator'])


def metrics(rows,mode,edit,threshold):
    attempted=[r for r in rows if r['edit']==edit]
    admitted=[r for r in attempted if r['first_exclusion'] is None]
    neg=[r for r in admitted if r['label']==0]; pos=[r for r in admitted if r['label']==1]
    groups=defaultdict(dict)
    for row in admitted: groups[row['context_id']][row['label']]=row
    matches=[g for g in groups.values() if set(g)=={0,1}]
    matched=[r for g in matches for r in g.values()]
    result={'rule':mode,'edit':edit,'attempted_pairs':len(attempted),'admitted_pairs':len(admitted),
        'first_exclusions':dict(Counter(r['first_exclusion'] for r in attempted if r['first_exclusion'])),
        'eligible_controls':len(neg),'eligible_embedding_event_positives':len(pos),'matched_contexts':len(matches),
        'represented_tasks':sorted({r['task'] for r in matched}),
        'distinct_original_texts_by_label':{str(y):len({r['original']['source_sha256'] for r in admitted if r['label']==y}) for y in (0,1)},
        'distinct_edited_texts_by_label':{str(y):len({r['edited']['source_sha256'] for r in admitted if r['label']==y}) for y in (0,1)}}
    for side in ('original','edited'):
        native=lambda r:r[side]['detections'][mode]['output']
        result[side]={'native_boolean_fpr_all_eligible_controls':rate([int(native(r)['is_watermarked']) for r in neg]),
            'native_boolean_tpr_all_eligible_embedding_positives':rate([int(native(r)['is_watermarked']) for r in pos]),
            'native_status_by_label':{str(y):dict(Counter(native(r)['decision_status'] for r in admitted if r['label']==y)) for y in (0,1)}}
        if threshold is not None:
            result[side]['selected_score_fpr']=rate([int(score(native(r))>=threshold) for r in neg])
            result[side]['selected_score_tpr']=rate([int(score(native(r))>=threshold) for r in pos])
        enough=len(result['represented_tasks'])>=2 and all(len({g[y]['original']['source_sha256'] for g in matches})>=2 for y in (0,1))
        if enough:
            scores={y:[score(native(g[y])) for g in matches] for y in (0,1)}
            result[side]['pooled_score_auc_matched_population']=auc(scores[1],scores[0])
            wins=sum(p>n for p,n in zip(scores[1],scores[0])); ties=sum(p==n for p,n in zip(scores[1],scores[0]))
            result[side]['within_context_auc']={'value':fraction(Fraction(2*wins+ties,2*len(matches))),
                                               'wins':wins,'ties':ties,'contexts':len(matches)}
        else:
            result[side]['auc_not_reported']='Fewer than2 represented families or distinct before texts per label'
    if 'pooled_score_auc_matched_population' in result['edited']:
        b=result['original']['pooled_score_auc_matched_population']['value']; a=result['edited']['pooled_score_auc_matched_population']['value']
        result['same_matched_population_auc_change']=fraction(as_fraction(a)-as_fraction(b))
    collisions=[g for g in matches if g[0]['edited']['source_sha256']==g[1]['edited']['source_sha256']]
    result['edited_same_text_origin_collisions']=len(collisions)
    need(all(g[0]['edited']['detections'][mode]==g[1]['edited']['detections'][mode] for g in collisions),'Same-input detector nondeterminism')
    result['by_task']={task:{'eligible_controls':sum(r['task']==task for r in neg),
        'eligible_positive_contexts':sum(r['task']==task for r in pos),
        'edited_native_control_hits':sum(r['task']==task and r['edited']['detections'][mode]['output']['is_watermarked'] for r in neg),
        'edited_native_positive_hits':sum(r['task']==task and r['edited']['detections'][mode]['output']['is_watermarked'] for r in pos)} for task in sorted({r['task'] for r in attempted})}
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('action',choices=('select','report'))
    p.add_argument('--development',type=Path,required=True); p.add_argument('--holdout',type=Path)
    p.add_argument('--freeze',type=Path,required=True); p.add_argument('--selection',type=Path)
    p.add_argument('--out',type=Path,required=True); a=p.parse_args()
    dev,dr=load(a.development,'development')
    if a.action=='select':
        value={'kind':'DEVELOPMENT_OPERATING_POINT_SELECTION','holdout_seen':False,
            'freeze_sha256':digest(a.freeze.read_bytes()),'development_raw_sha256':dr['pairs_sha256'],
            'score':'native positive_support_score','comparator':'ge',**choose(dev)}
    else:
        need(a.holdout and a.selection,'Holdout and frozen selection required')
        selected=read(a.selection); hold,hr=load(a.holdout,'holdout')
        need(selected['freeze_sha256']==digest(a.freeze.read_bytes()),'Frozen source differs')
        need(selected['development_raw_sha256']==dr['pairs_sha256'],'Development changed')
        need(selected['threshold']==choose(dev)['threshold'],'Selection not the predeclared rule')
        need(hr['selection_sha256_before_holdout']==digest(a.selection.read_bytes()),'Holdout preceded frozen selection')
        threshold=as_fraction(selected['threshold'])
        value={'kind':'DESCRIPTIVE_EDITED_ORIGIN_CONTROLS','selection':selected,
            'raw_sha256':{'development':dr['pairs_sha256'],'holdout':hr['pairs_sha256']},
            'counts':{k:dr['counts'].get(k,0)+hr['counts'].get(k,0) for k in set(dr['counts'])|set(hr['counts'])},
            'metrics':{split:[metrics(rows,mode,edit,threshold if mode=='registered' else None)
                for mode in ('registered','reconstructed') for edit in ('review-footer','reference-reimplementation')]
                for split,rows in (('development',dev),('holdout',hold))},
            'population_boundary':'Six constructed related task families, three held out; four payload schedules per task are dependent configurations. guarded_sum repeats the old task semantics. No independent sampling or population confidence interval.',
            'interpretation':'Scores rank native gate support conditional on a supplied task/payload schedule. Threshold selection is not probabilistic calibration. Native Boolean FPR is distinct from selected score FPR. Same-text collisions limit origin discrimination. No posterior prevalence or blind provenance follows.',
            'old_certificate_interface':'Unchanged: old positive-only inputs still cannot certify new negative/score claims.'}
    write_new(a.out,value)
    print(canonical({'action':a.action,'output':str(a.out),'threshold':value.get('threshold')}))


if __name__=='__main__': main()
